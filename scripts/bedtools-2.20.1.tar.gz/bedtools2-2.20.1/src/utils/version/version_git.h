#ifndef VERSION_GIT_H
#define VERSION_GIT_H
#define VERSION_GIT "v2.20.1"
#endif /* VERSION_GIT_H */
